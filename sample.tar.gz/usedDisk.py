import shutil

total_b, used_b, free_b = shutil.disk_usage('.')

print("Total: {:6.2f} GB".format(total_b / 1E9))
print("Used: {:6.2f} GB".format(used_b / 1E9))
print("Free: {:6.2f} GB".format(free_b / 1E9))