import pyqrcode

#QRString = "https://t.me/aomadhfianais"
QRString = "2Morow/omeAgain" # "2Dayw/omeAgain"

url = pyqrcode.create(QRString)

url.png("QR-code.png", scale=8)